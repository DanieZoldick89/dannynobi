-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 05 Okt 2022 pada 15.07
-- Versi server: 5.6.38
-- Versi PHP: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_keuangan`
--

DELIMITER $$
--
-- Fungsi
--
CREATE DEFINER=`root`@`localhost` FUNCTION `kode_automatis` (`kode` INT) RETURNS CHAR(7) CHARSET latin1 BEGIN
DECLARE kodebaru CHAR(7);
DECLARE urut INT;
 
SET urut = IF(kode IS NULL, 1, kode + 1);
SET kodebaru = CONCAT("TRX", LPAD(urut, 4, 0));
 
RETURN kodebaru;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `kode_automatis2` (`kode` INT) RETURNS CHAR(7) CHARSET latin1 BEGIN
DECLARE kodebaru CHAR(7);
DECLARE urut INT;
 
SET urut = IF(kode IS NULL, 1, kode + 1);
SET kodebaru = CONCAT("TRF", LPAD(urut, 4, 0));
 
RETURN kodebaru;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemasukkan`
--

CREATE TABLE `pemasukkan` (
  `id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` varchar(30) NOT NULL,
  `sumber` varchar(30) NOT NULL,
  `jumlah` varchar(250) NOT NULL,
  `username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pemasukkan`
--

INSERT INTO `pemasukkan` (`id`, `tanggal`, `keterangan`, `sumber`, `jumlah`, `username`) VALUES
(1, '2022-09-01', 'Gojek', 'Pekerjaan', '131300', 'danny32'),
(3, '2022-09-03', 'Gojek', 'Pekerjaan', '131500', 'danny32'),
(4, '2022-09-05', 'Gojek', 'Pekerjaan', '164300', 'danny32'),
(5, '2022-09-06', 'Gojek ', 'Pekerjaan', '101100', 'danny32'),
(6, '2022-09-07', 'Gojek', 'Pekerjaan', '137200', 'danny32'),
(7, '2022-09-18', 'Gojek', 'Pekerjaan', '58400', 'danny32'),
(8, '2022-09-19', 'Gojek', 'Pekerjaan', '130200', 'danny32'),
(9, '2022-09-21', 'Gojek', 'Pekerjaan', '126400', 'danny32'),
(10, '2022-09-22', 'Gojek', 'Pekerjaan', '81700', 'danny32'),
(11, '2022-09-23', 'Gojek', 'Pekerjaan', '103300', 'danny32'),
(12, '2022-09-24', 'Gojek', 'Pekerjaan', '61200', 'danny32'),
(13, '2022-09-26', 'Gojek', 'Pekerjaan', '142900', 'danny32'),
(14, '2022-09-27', 'Kas RT saldo sept 2022', 'Lain - lain', '1366900', 'rt004/013'),
(15, '2022-09-28', 'Kas saldo K3 Sept 2022', 'Lain - lain', '376600', 'rt004/013'),
(16, '2022-09-28', 'Kas PKK sept 2022', 'Lain - lain', '1301700', 'rt004/013'),
(17, '2022-09-28', 'Kas Donatur sept 2022', 'Lain - lain', '164600', 'rt004/013'),
(18, '2022-09-28', 'Kas Dansos sept 2022', 'Lain - lain', '413000', 'rt004/013'),
(19, '2022-09-28', 'Kas 17an sept 2022', 'Lain - lain', '342000', 'rt004/013'),
(20, '2022-09-28', 'Banop sept 2022', 'Lain - lain', '500', 'rt004/013'),
(21, '2022-10-02', 'Bude Yadi bayar iuran (paguyub', 'Lain - lain', '24000', 'rt004/013');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengeluaran`
--

CREATE TABLE `pengeluaran` (
  `id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` varchar(30) NOT NULL,
  `keperluan` varchar(30) NOT NULL,
  `jumlah` varchar(250) NOT NULL,
  `username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pengeluaran`
--

INSERT INTO `pengeluaran` (`id`, `tanggal`, `keterangan`, `keperluan`, `jumlah`, `username`) VALUES
(2, '2022-09-17', 'Bayar KTP', '', '150000', 'danny32'),
(3, '2022-09-18', 'Beli Obat', '', '33500', 'danny32'),
(4, '2022-09-20', 'Jajan Nasi Uduk ', '', '8000', 'danny32'),
(5, '2022-09-22', 'Bensin', '', '15000', 'danny32'),
(6, '2022-09-23', 'Bensin', '', '15000', 'danny32'),
(7, '2022-09-23', 'Jajan Bini', '', '20000', 'danny32'),
(8, '2022-09-23', 'Beli roti', '', '10000', 'danny32'),
(9, '2022-09-25', 'Nafkah', '', '275000', 'danny32'),
(10, '2022-09-28', 'Beli Keran dan Sarung Pingpong', '', '1080000', 'rt004/013'),
(11, '2022-09-27', 'Dana Jumantik (Kas PKK)', '', '60000', 'rt004/013'),
(12, '2022-09-29', 'Jenguk Bang Jaya (duit Kas RT)', '', '200000', 'rt004/013'),
(13, '2022-09-29', 'Beli Baju untuk RT dan Panitia', '', '860000', 'rt004/013'),
(14, '2022-10-02', 'Beli ATK (Kas RT)', '', '221000', 'rt004/013'),
(15, '2022-10-03', 'Posyandu (dari Kas PKK)', '', '84000', 'rt004/013');

-- --------------------------------------------------------

--
-- Struktur dari tabel `rekening_keluar`
--

CREATE TABLE `rekening_keluar` (
  `id` int(11) NOT NULL,
  `kode` varchar(10) NOT NULL,
  `jumlah` varchar(255) NOT NULL,
  `aksi` varchar(10) NOT NULL DEFAULT 'keluar',
  `tanggal` date NOT NULL,
  `username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `rekening_keluar`
--

INSERT INTO `rekening_keluar` (`id`, `kode`, `jumlah`, `aksi`, `tanggal`, `username`) VALUES
(1, 'TRF0001', '500000', 'keluar', '2022-09-18', 'danny32');

--
-- Trigger `rekening_keluar`
--
DELIMITER $$
CREATE TRIGGER `tg_kodekeluar` BEFORE INSERT ON `rekening_keluar` FOR EACH ROW BEGIN
DECLARE s VARCHAR(8);
DECLARE i INTEGER;
 
SET i = (SELECT SUBSTRING(kode,4,4) AS Nomer
FROM rekening_keluar ORDER BY Nomer DESC LIMIT 1);
 
SET s = (SELECT kode_automatis2(i));
 
IF(NEW.kode IS NULL OR NEW.kode = '')
 THEN SET NEW.kode =s;
END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `rekening_masuk`
--

CREATE TABLE `rekening_masuk` (
  `id` int(11) NOT NULL,
  `kode` varchar(10) NOT NULL,
  `jumlah` varchar(255) NOT NULL,
  `aksi` varchar(20) NOT NULL DEFAULT 'masuk',
  `tanggal` date NOT NULL,
  `username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Trigger `rekening_masuk`
--
DELIMITER $$
CREATE TRIGGER `tg_kodemasuk` BEFORE INSERT ON `rekening_masuk` FOR EACH ROW BEGIN
DECLARE s VARCHAR(8);
DECLARE i INTEGER;
 
SET i = (SELECT SUBSTRING(kode,4,4) AS Nomer
FROM rekening_masuk ORDER BY Nomer DESC LIMIT 1);
 
SET s = (SELECT kode_automatis(i));
 
IF(NEW.kode IS NULL OR NEW.kode = '')
 THEN SET NEW.kode =s;
END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'aktif',
  `level` varchar(10) NOT NULL DEFAULT 'user',
  `no_rek` char(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id_user`, `email`, `username`, `password`, `status`, `level`, `no_rek`) VALUES
(18, 'danny.nobiantoro57@gmail.com', 'danny89', '$2y$10$M/BJvANLAaTr59RbuIbkeeXkAZSHls.UXA3AJNokWtWe6R/khV/Hm', 'aktif', 'admin', '762161131200'),
(19, 'danny.gojek89@gmail.com', 'danny32', '$2y$10$XV3jFLRRQqhG.Q4h81t9Zu8Yc4uM9sEgFeOILuG89.17AgiaglCpi', 'aktif', 'user', '771741765956'),
(20, 'andikayanti24@gmail.com', 'dika24', '$2y$10$ll83mjMwH1sjofc.USOsDOXDORF7g4Hd7eyOjHdsI/13rN1VkxAzK', 'aktif', 'user', '517663099972'),
(21, 'danny.gojek90@gmail.com', 'rt004/013', '$2y$10$CPVSmqMh7zNvnqvcdRpLuua34ZRYRMBkuqSrCyjVB4AmSO0VYBJ5m', 'aktif', 'user', '787394624045');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `pemasukkan`
--
ALTER TABLE `pemasukkan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_username_masuk` (`username`);

--
-- Indeks untuk tabel `pengeluaran`
--
ALTER TABLE `pengeluaran`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_username_keluar` (`username`);

--
-- Indeks untuk tabel `rekening_keluar`
--
ALTER TABLE `rekening_keluar`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_username_rekening_keluar` (`username`);

--
-- Indeks untuk tabel `rekening_masuk`
--
ALTER TABLE `rekening_masuk`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_username_rekening_masuk` (`username`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `username` (`username`),
  ADD KEY `email` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `pemasukkan`
--
ALTER TABLE `pemasukkan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT untuk tabel `pengeluaran`
--
ALTER TABLE `pengeluaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT untuk tabel `rekening_keluar`
--
ALTER TABLE `rekening_keluar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `rekening_masuk`
--
ALTER TABLE `rekening_masuk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `pemasukkan`
--
ALTER TABLE `pemasukkan`
  ADD CONSTRAINT `fk_username_masuk` FOREIGN KEY (`username`) REFERENCES `users` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `pengeluaran`
--
ALTER TABLE `pengeluaran`
  ADD CONSTRAINT `fk_username_keluar` FOREIGN KEY (`username`) REFERENCES `users` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `rekening_keluar`
--
ALTER TABLE `rekening_keluar`
  ADD CONSTRAINT `fk_username_rekening_keluar` FOREIGN KEY (`username`) REFERENCES `users` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `rekening_masuk`
--
ALTER TABLE `rekening_masuk`
  ADD CONSTRAINT `fk_username_rekening_masuk` FOREIGN KEY (`username`) REFERENCES `users` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
