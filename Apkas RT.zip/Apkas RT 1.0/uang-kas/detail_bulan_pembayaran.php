<?php
require 'connection.php';
checkLogin();
$id_bulan_pembayaran = $_GET['id_bulan_pembayaran'];
$detail_bulan_pembayaran = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM bulan_pembayaran WHERE id_bulan_pembayaran = '$id_bulan_pembayaran'"));
$siswa = mysqli_query($conn, "SELECT * FROM siswa ORDER BY nama_siswa ASC");
$siswa_baru = mysqli_query($conn, "SELECT * FROM siswa WHERE id_siswa NOT IN (SELECT id_siswa FROM uang_kas) ORDER BY nama_siswa ASC");
$uang_kas = mysqli_query($conn, "SELECT * FROM uang_kas INNER JOIN siswa ON uang_kas.id_siswa = siswa.id_siswa INNER JOIN bulan_pembayaran ON uang_kas.id_bulan_pembayaran = bulan_pembayaran.id_bulan_pembayaran WHERE uang_kas.id_bulan_pembayaran = '$id_bulan_pembayaran' ORDER BY nama_siswa ASC");

$bulan_pembayaran_pertama = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM bulan_pembayaran ORDER BY id_bulan_pembayaran ASC LIMIT 1"));
$id_bulan_pembayaran_pertama = $bulan_pembayaran_pertama['id_bulan_pembayaran'];

$id_bulan_pembayaran_sebelum = $id_bulan_pembayaran - 1;
if ($id_bulan_pembayaran_sebelum <= 0) {
  $id_bulan_pembayaran_sebelum = 1;
}

if ($id_bulan_pembayaran != $id_bulan_pembayaran_pertama) {
  $uang_kas_bulan_sebelum = mysqli_query($conn, "SELECT * FROM uang_kas INNER JOIN siswa ON uang_kas.id_siswa = siswa.id_siswa INNER JOIN bulan_pembayaran ON uang_kas.id_bulan_pembayaran = bulan_pembayaran.id_bulan_pembayaran WHERE uang_kas.id_bulan_pembayaran = $id_bulan_pembayaran_sebelum ORDER BY nama_siswa ASC");
}

if (isset($_POST['btnEditPembayaranUangKas'])) {
  if (editPembayaranUangKas($_POST) > 0) {
    setAlert("Pembayaran has been changed", "Successfully changed", "success");
    header("Location: detail_bulan_pembayaran.php?id_bulan_pembayaran=$id_bulan_pembayaran");
  }
}

if (isset($_POST['btnTambahSiswa'])) {
  if (tambahSiswaUangKas($_POST) > 0) {
    setAlert("Warga has been added", "Successfully added", "success");
    header("Location: detail_bulan_pembayaran.php?id_bulan_pembayaran=$id_bulan_pembayaran");
  }
}

?>
 
<!DOCTYPE html>
<html>

<head>
  <?php include 'include/css.php'; ?>
  <title>Detail Bulan Pembayaran</title>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <?php include 'include/navbar.php'; ?>

    <?php include 'include/sidebar.php'; ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row justify-content-center mb-2">
            <div class="col-sm text-left">
              <h1 class="m-0 text-dark">Detail Bulan Pembayaran : <?= ucwords($detail_bulan_pembayaran['nama_bulan']); ?> <?= $detail_bulan_pembayaran['tahun']; ?></h1>
            </div><!-- /.col -->
            <div class="col-sm text-right">
              <?php if ($_SESSION['id_jabatan'] !== '3') : ?>
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambahSiswaModal"><i class="fas fa-fw fa-plus"></i> Tambah Warga</button>
                <!-- Modal -->
                <div class="modal fade text-left" id="tambahSiswaModal" tabindex="-1" role="dialog" aria-labelledby="tambahSiswaModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <form method="post">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="tambahSiswaModalLabel">Tambah Warga</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <div class="form-group">
                            <label for="nama_siswa">Nama Warga</label>
                            <input type="text" id="nama_siswa" name="nama_siswa" class="form-control" required>
                          </div>
                          <div class="form-group">
                            <label for="no_telepon">No.Telepon</label>
                            <input type="number" name="no_telepon" id="no_telepon" class="form-control">
                          </div>
                          <div class="form-group">
                            <label for="no_rumah">No.Rumah</label>
                            <input type="number" name="no_rumah" id="no_rumah" class="form-control">
                          </div>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fas fa-fw fa-times"></i> Close</button>
                          <button type="submit" class="btn btn-primary" name="btnTambahSiswa"><i class="fas fa-fw fa-save"></i> Save</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              <?php endif ?>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg">
              <div class="table-responsive">
                <table class="table table-striped table-hover table-bordered" id="table_id">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Nama Warga</th>
                      <th>Kas RT</th>
                      <th>Kas PKK</th>
                      <th>Dana Sosial</th>
                      <th>Kas 17an</th>
                      <?php if ($_SESSION['id_jabatan'] !== '3') : ?>
                        <th>Aksi</th>
                      <?php endif ?>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($uang_kas as $ds) : ?>
                      <tr>
                        <td><?= $i++; ?></td>
                        <td><?= ucwords(htmlspecialchars_decode($ds['nama_siswa'])); ?></td>
                        <td><?= $ds['kas_rt']; ?></td>
                        <td><?= $ds['kas_pkk']; ?></td>
                        <td><?= $ds['dansos']; ?></td>
                        <td><?= $ds['kas_17']; ?></td>
                        <?php if ($_SESSION['id_jabatan'] !== '3') : ?>
                          <td>
                            <!-- Button trigger modal -->
                            <a href="ubah_uang_kas.php?id_uang_kas=<?= $ds['id_uang_kas']; ?>" class="badge badge-success" data-toggle="modal" data-target="#editUangKas<?= $ds['id_uang_kas']; ?>">
                              <i class="fas fa-fw fa-edit"></i> Ubah
                            </a>
                            <!-- Modal -->
                            <div class="modal fade" id="editUangKas<?= $ds['id_uang_kas']; ?>" tabindex="-1" role="dialog" aria-labelledby="editUangKas<?= $ds['id_uang_kas']; ?>" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                <form method="post">
                                  <input type="hidden" name="id_uang_kas" value="<?= $ds['id_uang_kas']; ?>">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title" id="editSiswaModalLabel<?= $ds['id_siswa']; ?>">Ubah Warga</h5>
                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                      </button>
                                    </div>
                                    <div class="modal-body">
                                      <div class="form-group">
                                        <label for="nama_siswa<?= $ds['id_siswa']; ?>">Nama Warga</label>
                                        <input type="text" id="nama_siswa<?= $ds['id_siswa']; ?>" value="<?= $ds['nama_siswa']; ?>" name="nama_siswa" class="form-control" required>
                                      </div>
                                                                          <div class="form-group">
                                        <label for="kas_rt<?= $ds['id_uang_kas']; ?>">Kas RT</label>
                                        <input type="number" name="kas_rt" value="<?= $ds['kas_rt']; ?>" id="kas_rt<?= $ds['id_uang_kas']; ?>" class="form-control">
                                      </div>
                                      <div class="form-group">
                                        <label for="kas_pkk<?= $ds['id_uang_kas']; ?>">Kas PKK</label>
                                        <input type="number" name="kas_pkk" value="<?= $ds['kas_pkk']; ?>" id="kas_pkk<?= $ds['id_uang_kas']; ?>" class="form-control">
                                      </div>

<div class="form-group">
                                        <label for="dansos<?= $ds['id_uang_kas']; ?>">Dana Sosial</label>
                                        <input type="number" name="dansos" value="<?= $ds['dansos']; ?>" id="dansos<?= $ds['id_uang_kas']; ?>" class="form-control">
                                      </div>


<div class="form-group">
                                        <label for="kas_17<?= $ds['id_uang_kas']; ?>">Kas 17an</label>
                                        <input type="number" name="kas_17" value="<?= $ds['kas_17']; ?>" id="kas_17<?= $ds['id_uang_kas']; ?>" class="form-control">
                                      </div>
                                    </div>
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fas fa-fw fa-times"></i> Close</button>
                                      <button type="submit" class="btn btn-primary" name="btnEditPembayaranUangKas"><i class="fas fa-fw fa-save"></i> Save</button>
                                    </div>
                                  </div>
                                </form>
                              </div>
                            </div>
                            <?php if ($_SESSION['id_jabatan'] == '1') : ?>
                              <a data-nama="<?= $ds['uang_kas']; ?>" class="btn-delete badge badge-danger" href="hapus_uang_kas.php?id_uang_kas=<?= $ds['id_uang_kas']; ?>"><i class="fas fa-fw fa-trash"></i> Hapus</a>
                            <?php endif ?>
                          </td>
                        <?php endif ?>
                      </tr>
                    <?php endforeach ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <footer class="main-footer">
=      <strong>Copyright &copy; 2022 By Danny Nobi.</strong>
      All rights reserved. | Repost by DanieZoldick89
      <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0.0
      </div>
    </footer>

  </div>
</body>

</html>
             