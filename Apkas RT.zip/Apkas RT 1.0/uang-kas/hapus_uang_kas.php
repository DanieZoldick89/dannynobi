<?php 
	require 'connection.php';
	$id_uang_kas = $_GET['id_uang_kas'];
	if (isset($id_uang_kas)) {
		if (deleteUangKas($id_uang_kas) > 0) {
			setAlert("Uang Kas has been deleted", "Successfully deleted", "success");
		    header("Location: uang_kas.php");
	    }
	} else {
	   header("Location: uang_kas.php");
	}