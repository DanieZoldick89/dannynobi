-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 05 Okt 2022 pada 15.05
-- Versi server: 5.6.38
-- Versi PHP: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uang_kas`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `bulan_pembayaran`
--

CREATE TABLE `bulan_pembayaran` (
  `id_bulan_pembayaran` int(11) NOT NULL,
  `nama_bulan` enum('januari','februari','maret','april','mei','juni','juli','agustus','september','oktober','november','desember') NOT NULL,
  `tahun` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `bulan_pembayaran`
--

INSERT INTO `bulan_pembayaran` (`id_bulan_pembayaran`, `nama_bulan`, `tahun`) VALUES
(4, 'oktober', 2022);

-- --------------------------------------------------------

--
-- Struktur dari tabel `jabatan`
--

CREATE TABLE `jabatan` (
  `id_jabatan` int(11) NOT NULL,
  `nama_jabatan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `jabatan`
--

INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES
(1, 'administrator'),
(4, 'RT'),
(5, 'Bendahara');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengeluaran`
--

CREATE TABLE `pengeluaran` (
  `id_pengeluaran` int(11) NOT NULL,
  `jumlah_pengeluaran` int(11) NOT NULL,
  `keterangan` text NOT NULL,
  `tanggal_pengeluaran` int(11) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `riwayat`
--

CREATE TABLE `riwayat` (
  `id_riwayat` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_uang_kas` int(11) NOT NULL,
  `aksi` text NOT NULL,
  `tanggal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `riwayat`
--

INSERT INTO `riwayat` (`id_riwayat`, `id_user`, `id_uang_kas`, `aksi`, `tanggal`) VALUES
(1, 1, 2, 'telah mengubah pembayaran minggu ke-1 dari Rp. 0 menjadi Rp. 5,000', 1611256476),
(2, 1, 2, 'telah mengubah pembayaran minggu ke-2 dari Rp. 0 menjadi Rp. 5,000', 1611256479),
(3, 1, 2, 'telah mengubah pembayaran minggu ke-3 dari Rp. 0 menjadi Rp. 5,000', 1611256484),
(4, 1, 2, 'telah mengubah pembayaran minggu ke-4 dari Rp. 0 menjadi Rp. 4,000', 1611256488),
(5, 1, 1, 'telah mengubah pembayaran minggu ke-1 dari Rp. 0 menjadi Rp. 5,000', 1611256492),
(6, 1, 1, 'telah mengubah pembayaran minggu ke-2 dari Rp. 0 menjadi Rp. 5,000', 1611256495),
(7, 1, 1, 'telah mengubah pembayaran minggu ke-3 dari Rp. 0 menjadi Rp. 5,000', 1611256500),
(8, 1, 1, 'telah mengubah pembayaran minggu ke-4 dari Rp. 0 menjadi Rp. 5,000', 1611256504),
(9, 1, 3, 'telah mengubah pembayaran minggu ke-1 dari Rp. 0 menjadi Rp. 5,000', 1611256508),
(10, 1, 3, 'telah mengubah pembayaran minggu ke-2 dari Rp. 0 menjadi Rp. 5,000', 1611256512),
(11, 1, 4, 'telah mengubah pembayaran minggu ke-1 dari Rp. 0 menjadi Rp. 500', 1611256518),
(12, 1, 4, 'telah mengubah pembayaran minggu ke-1 dari Rp. 500 menjadi Rp. 5,000', 1611256526),
(13, 1, 5, 'telah mengubah pembayaran minggu ke-1 dari Rp. 0 menjadi Rp. 5,000', 1611256530),
(14, 1, 5, 'telah mengubah pembayaran minggu ke-2 dari Rp. 0 menjadi Rp. 5,000', 1611256534),
(15, 1, 2, 'telah mengubah pembayaran minggu ke-4 dari Rp. 4,000 menjadi Rp. 3,000', 1611257026),
(16, 1, 2, 'telah mengubah pembayaran minggu ke-4 dari Rp. 3,000 menjadi Rp. 5,000', 1652453172),
(17, 1, 3, 'telah mengubah pembayaran minggu ke-3 dari Rp. 0 menjadi Rp. 5,000', 1652453181),
(18, 1, 3, 'telah mengubah pembayaran minggu ke-4 dari Rp. 0 menjadi Rp. 5,000', 1652453187),
(19, 1, 4, 'telah mengubah pembayaran minggu ke-2 dari Rp. 0 menjadi Rp. 5,000', 1652453192),
(20, 1, 4, 'telah mengubah pembayaran minggu ke-3 dari Rp. 0 menjadi Rp. 5,000', 1652453196),
(21, 1, 4, 'telah mengubah pembayaran minggu ke-4 dari Rp. 0 menjadi Rp. 5,000', 1652453201),
(22, 1, 5, 'telah mengubah pembayaran minggu ke-3 dari Rp. 0 menjadi Rp. 5,000', 1652453205),
(23, 1, 5, 'telah mengubah pembayaran minggu ke-4 dari Rp. 0 menjadi Rp. 5,000', 1652453209),
(24, 1, 11, 'telah mengubah pembayaran minggu ke-1 dari Rp. 0 menjadi Rp. 5,000', 1652453353),
(25, 1, 11, 'telah mengubah pembayaran minggu ke-2 dari Rp. 0 menjadi Rp. 5,000', 1652453358),
(26, 1, 11, 'telah mengubah pembayaran minggu ke-3 dari Rp. 0 menjadi Rp. 5,000', 1652453362),
(27, 1, 11, 'telah mengubah pembayaran minggu ke-4 dari Rp. 0 menjadi Rp. 5,000', 1652453366),
(28, 2, 11, 'telah mengubah pembayaran minggu ke-4 dari Rp. 5,000 menjadi Rp. 1,000', 1652454260),
(29, 2, 11, 'telah mengubah pembayaran minggu ke-4 dari Rp. 1,000 menjadi Rp. 5,000', 1652454272),
(30, 1, 7, 'telah mengubah pembayaran minggu ke-1 dari Rp. 0 menjadi Rp. 5,000', 1664234908),
(31, 1, 17, 'telah mengubah pembayaran minggu ke-1 dari Rp. 0 menjadi Rp. 5,000', 1664250543),
(32, 1, 17, 'telah mengubah pembayaran minggu ke-1 dari Rp. 5,000 menjadi Rp. 7,000', 1664250556),
(33, 1, 20, 'telah mengubah pembayaran minggu ke-1 dari Rp. 0 menjadi Rp. 7,000', 1664288529),
(34, 1, 20, 'telah mengubah pembayaran minggu ke-1 dari Rp. 7,000 menjadi Rp. ', 1664288934),
(35, 1, 20, 'telah mengubah pembayaran minggu ke-1 dari Rp. 0 menjadi Rp. 7,000', 1664288961),
(36, 1, 20, 'telah mengubah pembayaran minggu ke-2 dari Rp. 0 menjadi Rp. 5,000', 1664289350),
(37, 1, 20, 'telah mengubah pembayaran minggu ke-2 dari Rp. 5,000 menjadi Rp. ', 1664289399),
(38, 1, 20, 'telah mengubah pembayaran minggu ke-1 dari Rp. 7,000 menjadi Rp. ', 1664289405),
(39, 1, 26, 'telah mengubah pembayaran minggu ke-1 dari Rp. 0 menjadi Rp. 7,000', 1664289584),
(40, 1, 25, 'telah mengubah pembayaran minggu ke-1 dari Rp. 0 menjadi Rp. 7,000', 1664289633),
(41, 1, 26, 'telah mengubah pembayaran minggu ke-1 dari Rp. 7,000 menjadi Rp. 27,000', 1664289653),
(42, 1, 26, 'telah mengubah pembayaran minggu ke-1 dari Rp. 27,000 menjadi Rp. ', 1664289692),
(43, 1, 25, 'telah mengubah pembayaran minggu ke-1 dari Rp. 7,000 menjadi Rp. ', 1664289697),
(44, 1, 32, 'telah mengubah pembayaran minggu ke-1 dari Rp. 0 menjadi Rp. 7,000', 1664289809),
(45, 1, 32, 'telah mengubah pembayaran minggu ke-2 dari Rp. 0 menjadi Rp. 7,000', 1664289822),
(46, 1, 32, 'telah mengubah pembayaran minggu ke-3 dari Rp. 0 menjadi Rp. 7,000', 1664289831),
(47, 1, 32, 'telah mengubah pembayaran minggu ke-4 dari Rp. 0 menjadi Rp. 7,000', 1664289839),
(48, 1, 31, 'telah mengubah pembayaran minggu ke-1 dari Rp. 0 menjadi Rp. 7,000', 1664290710),
(49, 1, 31, 'telah mengubah pembayaran minggu ke-2 dari Rp. 0 menjadi Rp. 7,000', 1664290722),
(50, 1, 31, 'telah mengubah pembayaran minggu ke-3 dari Rp. 0 menjadi Rp. 7,000', 1664290741),
(51, 1, 31, 'telah mengubah pembayaran minggu ke-4 dari Rp. 0 menjadi Rp. 7,000', 1664290750),
(52, 4, 33, 'telah mengubah pembayaran minggu ke-1 dari Rp. 0 menjadi Rp. 0', 1664317978),
(53, 4, 33, 'telah mengubah pembayaran minggu ke-1 dari Rp. 0 menjadi Rp. 0', 1664317987),
(54, 4, 33, 'telah mengubah pembayaran minggu ke-1 dari Rp. 0 menjadi Rp. 7,000', 1664317999),
(55, 4, 33, 'telah mengubah pembayaran minggu ke-2 dari Rp. 0 menjadi Rp. 5,000', 1664318093),
(56, 4, 33, 'telah mengubah pembayaran minggu ke-2 dari Rp. 5,000 menjadi Rp. 0', 1664318107),
(57, 4, 33, 'telah mengubah pembayaran minggu ke-2 dari Rp. 0 menjadi Rp. 10', 1664318116),
(58, 4, 33, 'telah mengubah pembayaran minggu ke-2 dari Rp. 10 menjadi Rp. 0', 1664318126),
(59, 4, 33, 'telah mengubah pembayaran minggu ke-1 dari Rp. 7,000 menjadi Rp. 0', 1664318132),
(60, 4, 31, 'telah mengubah pembayaran minggu ke-4 dari Rp. 7,000 menjadi Rp. 7', 1664318297),
(61, 4, 31, 'telah mengubah pembayaran minggu ke-4 dari Rp. 7 menjadi Rp. 7,000', 1664318474),
(62, 1, 22, 'telah mengubah pembayaran minggu ke-1 dari Rp. 0 menjadi Rp. 7,000', 1664370493),
(63, 1, 43, 'telah mengubah pembayaran minggu ke-4 dari Rp.  menjadi Rp. 8,000', 1664460139),
(64, 1, 49, 'telah mengubah pembayaran minggu ke-4 dari Rp.  menjadi Rp. 9,000', 1664460150),
(65, 1, 1, 'telah mengubah pembayaran kas rt dari Rp.  menjadi Rp. 5,000', 1664863624),
(66, 1, 1, 'telah mengubah pembayaran kas rt dari Rp.  menjadi Rp. 5,000', 1664863642),
(67, 1, 1, 'telah mengubah pembayaran kas rt dari Rp.  menjadi Rp. 0', 1664885315),
(68, 1, 1, 'telah mengubah pembayaran kas rt dari Rp.  menjadi Rp. 5,000', 1664885333),
(69, 1, 1, 'telah mengubah pembayaran kas rt dari Rp.  menjadi Rp. 7,000', 1664885345),
(70, 1, 7, 'telah mengubah pembayaran kas rt dari Rp.  menjadi Rp. 5,000', 1664885359),
(71, 1, 7, 'telah mengubah pembayaran kas rt dari Rp.  menjadi Rp. 5,000', 1664885369),
(72, 1, 7, 'telah mengubah pembayaran kas rt dari Rp.  menjadi Rp. 6,000', 1664885385),
(73, 1, 1, 'telah mengubah pembayaran kas rt dari Rp.  menjadi Rp. 7,000', 1664885778),
(74, 1, 15, 'telah mengubah pembayaran kas rt dari Rp.  menjadi Rp. 5,000', 1664887843),
(75, 1, 5, 'telah mengubah pembayaran kas rt dari Rp.  menjadi Rp. 5,000', 1664887995);

-- --------------------------------------------------------

--
-- Struktur dari tabel `riwayat_pengeluaran`
--

CREATE TABLE `riwayat_pengeluaran` (
  `id_riwayat_pengeluaran` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `aksi` text NOT NULL,
  `tanggal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `riwayat_pengeluaran`
--

INSERT INTO `riwayat_pengeluaran` (`id_riwayat_pengeluaran`, `id_user`, `aksi`, `tanggal`) VALUES
(1, 1, 'telah menambahkan pengeluaran Pembersih lantai dengan biaya Rp. 2,000', 1611256576),
(2, 1, 'telah menambahkan pengeluaran sapu x1 dengan biaya Rp. 10,000', 1611256589),
(3, 1, 'telah mengubah pengeluaran Pembersih lantai 2x dari biaya Rp. 2,000 menjadi Rp. 2,000', 1611256595),
(4, 1, 'telah mengubah pengeluaran Pembersih lantai x2 dari biaya Rp. 2,000 menjadi Rp. 2,000', 1611256599),
(5, 1, 'telah menambahkan pengeluaran Beli Sapu 2pcs dengan biaya Rp. 20,000', 1652453635),
(6, 1, 'telah menambahkan pengeluaran Beli Pel Lantai 2pcs dengan biaya Rp. 28,000', 1652453668),
(7, 1, 'telah menambahkan pengeluaran Beli Sabun Pel 12pcs (1 renceng) dengan biaya Rp. 10,000', 1652453690),
(8, 1, 'telah menambahkan pengeluaran Beli Spidol hitam 3pcs dengan biaya Rp. 30,000', 1652453749),
(9, 1, 'telah menambahkan pengeluaran Penghapus Papan Tulis dengan biaya Rp. 9,000', 1652453779),
(10, 1, 'telah mengubah pengeluaran Beli Spidol hitam 2pcs dari biaya Rp. 30,000 menjadi Rp. 20,000', 1652453803),
(11, 1, 'telah menambahkan pengeluaran Ember Anti Pecah dengan biaya Rp. 35,000', 1652453820),
(12, 1, 'telah mengubah pengeluaran Beli Wipol Pel 12pcs (1 renceng) dari biaya Rp. 10,000 menjadi Rp. 10,000', 1652453855),
(13, 1, 'telah mengubah pengeluaran Beli Pel Lantai 1pcs dari biaya Rp. 28,000 menjadi Rp. 15,000', 1652453877),
(14, 1, 'telah mengubah pengeluaran Ember Anti Pecah dari biaya Rp. 35,000 menjadi Rp. 40,000', 1652453886),
(15, 1, 'telah mengubah pengeluaran Beli Spidol Hitam 2pcs dari biaya Rp. 20,000 menjadi Rp. 20,000', 1652453900),
(16, 1, 'telah menambahkan pengeluaran Beli ATK dengan biaya Rp. 20,000', 1664290865);

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa`
--

CREATE TABLE `siswa` (
  `id_siswa` int(11) NOT NULL,
  `nama_siswa` varchar(100) NOT NULL,
  `no_telepon` varchar(25) NOT NULL,
  `no_rumah` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `siswa`
--

INSERT INTO `siswa` (`id_siswa`, `nama_siswa`, `no_telepon`, `no_rumah`) VALUES
(10, 'Bapak Oscar ', '', ''),
(11, 'Bu Herawanto', '', ''),
(12, 'Bu Suyadi', '', ''),
(13, 'Bu Nurdin', '', ''),
(14, 'Bu Azis', '', ''),
(15, 'Bu Guntoro', '', ''),
(16, 'Bu Ade', '', ''),
(17, 'Bu Warta', '', ''),
(18, 'Bu sopyan', '', ''),
(19, 'Bu Hikmah ', '', ''),
(20, 'Bu Ricky', '', ''),
(21, 'Mbak Puja', '', ''),
(22, 'Bu Tama', '', ''),
(23, 'Bu Novan', '', ''),
(24, 'Bu Aulia', '', ''),
(25, 'Bu Haryono ', '', ''),
(26, 'Bu Kamil', '', ''),
(27, 'Bu Danny', '', '284'),
(28, 'Bu Suhendi', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `uang_kas`
--

CREATE TABLE `uang_kas` (
  `id_uang_kas` int(11) NOT NULL,
  `id_siswa` int(11) NOT NULL,
  `id_bulan_pembayaran` int(11) NOT NULL,
  `kas_rt` int(11) DEFAULT NULL,
  `kas_pkk` int(11) DEFAULT NULL,
  `dansos` int(11) DEFAULT NULL,
  `kas_17` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `uang_kas`
--

INSERT INTO `uang_kas` (`id_uang_kas`, `id_siswa`, `id_bulan_pembayaran`, `kas_rt`, `kas_pkk`, `dansos`, `kas_17`) VALUES
(20, 10, 4, 5000, 6000, 7000, 8000),
(21, 11, 4, 0, 0, 0, 0),
(22, 12, 4, 0, 0, 0, 0),
(23, 13, 4, 0, 0, 0, 0),
(24, 14, 4, 0, 0, 0, 0),
(25, 15, 4, 0, 0, 0, 0),
(26, 16, 4, 0, 0, 0, 0),
(27, 17, 4, 0, 0, 0, 0),
(28, 18, 4, 0, 0, 0, 0),
(29, 19, 4, 0, 0, 0, 0),
(30, 20, 4, 0, 0, 0, 0),
(31, 21, 4, 0, 0, 0, 0),
(32, 22, 4, 0, 0, 0, 0),
(33, 23, 4, 0, 0, 0, 0),
(34, 24, 4, 0, 5000, 0, 5000),
(35, 25, 4, 0, 0, 0, 0),
(36, 26, 4, 0, 0, 0, 0),
(37, 27, 4, 0, 0, 0, 0),
(38, 28, 4, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `id_jabatan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `nama_lengkap`, `username`, `password`, `id_jabatan`) VALUES
(1, 'Danny Nobiantoro', 'danny123', '$2y$10$RtlG8gY2cp/2BYEeMBJ2C.tMli1qvWGCoT/jkKIZVNrRJ/4cGbbTm', 1),
(4, 'Aryadi Gunawan', 'RT4/13', '$2y$10$vkDZeXwi0EOMijvZdI5vSepVw0bUGq5/cZUJ2vkM77yRVtyWKiqni', 4),
(5, 'Andika Yanti ', 'dika89', '$2y$10$VVqcf/DmTh790c6KmDLu8.jtABi7zRV8EogTVM/G2DX.aWgWch8D.', 5);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `bulan_pembayaran`
--
ALTER TABLE `bulan_pembayaran`
  ADD PRIMARY KEY (`id_bulan_pembayaran`);

--
-- Indeks untuk tabel `jabatan`
--
ALTER TABLE `jabatan`
  ADD PRIMARY KEY (`id_jabatan`);

--
-- Indeks untuk tabel `pengeluaran`
--
ALTER TABLE `pengeluaran`
  ADD PRIMARY KEY (`id_pengeluaran`),
  ADD KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `riwayat`
--
ALTER TABLE `riwayat`
  ADD PRIMARY KEY (`id_riwayat`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_uang_kas` (`id_uang_kas`);

--
-- Indeks untuk tabel `riwayat_pengeluaran`
--
ALTER TABLE `riwayat_pengeluaran`
  ADD PRIMARY KEY (`id_riwayat_pengeluaran`),
  ADD KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id_siswa`);

--
-- Indeks untuk tabel `uang_kas`
--
ALTER TABLE `uang_kas`
  ADD PRIMARY KEY (`id_uang_kas`),
  ADD KEY `id_siswa` (`id_siswa`),
  ADD KEY `id_bulan_pembayaran` (`id_bulan_pembayaran`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `id_jabatan` (`id_jabatan`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `bulan_pembayaran`
--
ALTER TABLE `bulan_pembayaran`
  MODIFY `id_bulan_pembayaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `jabatan`
--
ALTER TABLE `jabatan`
  MODIFY `id_jabatan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `pengeluaran`
--
ALTER TABLE `pengeluaran`
  MODIFY `id_pengeluaran` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `riwayat`
--
ALTER TABLE `riwayat`
  MODIFY `id_riwayat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT untuk tabel `riwayat_pengeluaran`
--
ALTER TABLE `riwayat_pengeluaran`
  MODIFY `id_riwayat_pengeluaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `siswa`
--
ALTER TABLE `siswa`
  MODIFY `id_siswa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT untuk tabel `uang_kas`
--
ALTER TABLE `uang_kas`
  MODIFY `id_uang_kas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
